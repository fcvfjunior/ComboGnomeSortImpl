package sorting.variationsOfBubblesort;

import sorting.AbstractSorting;
import util.Util;

/**
 * The combsort algoritm.
 */


public class CombSort<T extends Comparable<T>> extends AbstractSorting<T> {
	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		
		if (rightIndex <= 0) {
			return;
		}
		
		int diferenca = rightIndex;
		boolean troca = false;
		
		while (diferenca > 1 || troca) {
			if (diferenca > 1) {
				diferenca = (int)(diferenca / 1.25);
			}
			
			int indiceEsq = leftIndex;
			troca = false;
			for (int i = indiceEsq + diferenca; i <= rightIndex; i++) {
				if (array[indiceEsq].compareTo(array[indiceEsq + diferenca]) > 0) {
					Util.swap(array, indiceEsq, i);
					troca = true;
				}
				indiceEsq++;
			}
		}
		
		
	}
	
	
}
